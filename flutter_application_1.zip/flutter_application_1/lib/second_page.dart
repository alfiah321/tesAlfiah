import 'package:flutter/material.dart';
import 'package:flutter_application_1/first_page.dart';

class secondPage extends StatefulWidget {
  const secondPage({super.key});

  @override
  State<secondPage> createState() => _secondPageState();
}

class _secondPageState extends State<secondPage> {
  List<int> _primeNumbers = [];
  TextEditingController controllerAngka = TextEditingController();

  bool _isPrime(int number) {
    if (number < 2) {
      return false;
    }
    for (int i = 2; i <= number / 2; i++) {
      if (number % i == 0) return false;
    }

    print('{$number} bilangan prima');
    return true;
  }

  void generateBilanganPrima() {
    int angka = 100;
    for (int i = 1; i <= angka; i++) {
      // print(i);
      if (_isPrime(i)) {
        _primeNumbers.add(i);
        print(_primeNumbers);
      }
      // print(_primeNumbers);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: Text(''),
          leading: IconButton(
              onPressed: () {
                Navigator.pushReplacement(context,
                    MaterialPageRoute(builder: (context) => HomePage()));
              },
              icon: Icon(Icons.arrow_back)),
        ),
        body: Container(
          margin: EdgeInsets.all(10.0),
          padding: EdgeInsets.all(2),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              SizedBox(
                height: 20,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    'images/download.jpg',
                    width: 50,
                    height: 50,
                  ),
                  Text(
                    'Build App',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 20),
                  ),
                ],
              ),
              SizedBox(
                height: 100,
              ),
              Text(
                'Bilangan Prima',
                textAlign: TextAlign.right,
                style: TextStyle(fontSize: 24),
              ),
              Text('Masukkan Angka untuk mengahsilkan bilangan prima ',
                  textAlign: TextAlign.right, style: TextStyle(fontSize: 12)),
              // Text('Input Angka ',
              //     textAlign: TextAlign.right, style: TextStyle(fontSize: 12)),
              TextField(
                controller: controllerAngka,
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  hintText: "Email Adress",
                  // labelText: "Input Angka"
                ),
              ),
              SizedBox(
                height: 50,
              ),
              Container(
                width: double.infinity,
                margin: EdgeInsets.symmetric(horizontal: 10),
                child: ElevatedButton(
                    onPressed: () {
                      generateBilanganPrima();
                    },
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        padding:
                            EdgeInsets.symmetric(horizontal: 12, vertical: 12)),
                    child: Text(
                      'GENERATE BILANGAN PRIMA',
                      style: TextStyle(color: Colors.white),
                    )),
              ),
              // Container(
              //   child: ListView.builder(
              //     itemCount: _primeNumbers.length,
              //     itemBuilder: (BuildContext context, int index) {
              //       // return Text('Bilangan prima :  ${_primeNumbers[index]}');
              //       return Text(_primeNumbers[index] as String);
              //     },
              //   ),
              // )
              //  Text(_primeNumbers[])
              // if (_primeNumbers.isNotEmpty)
              // Text('Bilangan prima :  {$_primeNumbers}')
              // print(_primeNumbers)
              // Text(_primeNumbers.join(' '))
            ],
          ),
        ),
      ),
    );
  }
}
